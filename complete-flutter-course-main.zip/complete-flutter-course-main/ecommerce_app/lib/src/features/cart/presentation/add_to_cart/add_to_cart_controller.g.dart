// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_to_cart_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$addToCartControllerHash() =>
    r'9561d9e66460bf7ea99dce03b7a5900b38a7f930';

/// See also [AddToCartController].
@ProviderFor(AddToCartController)
final addToCartControllerProvider =
    AutoDisposeAsyncNotifierProvider<AddToCartController, void>.internal(
  AddToCartController.new,
  name: r'addToCartControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$addToCartControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AddToCartController = AutoDisposeAsyncNotifier<void>;
String _$itemQuantityControllerHash() =>
    r'e3aebb6b912ee6ef8fd2ff6b1ab26201380f7862';

/// See also [ItemQuantityController].
@ProviderFor(ItemQuantityController)
final itemQuantityControllerProvider =
    AutoDisposeNotifierProvider<ItemQuantityController, int>.internal(
  ItemQuantityController.new,
  name: r'itemQuantityControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$itemQuantityControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ItemQuantityController = AutoDisposeNotifier<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
