// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'local_cart_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$localCartRepositoryHash() =>
    r'a9f6d6a53c7543c55e78dc753787171b1a62b066';

/// See also [localCartRepository].
@ProviderFor(localCartRepository)
final localCartRepositoryProvider = Provider<LocalCartRepository>.internal(
  localCartRepository,
  name: r'localCartRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$localCartRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef LocalCartRepositoryRef = ProviderRef<LocalCartRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
