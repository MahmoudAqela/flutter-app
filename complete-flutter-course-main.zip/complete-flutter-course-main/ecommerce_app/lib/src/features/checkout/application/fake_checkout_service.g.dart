// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fake_checkout_service.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$checkoutServiceHash() => r'64059580e5b7c6948bebd08bd5f4b4f5342cb607';

/// See also [checkoutService].
@ProviderFor(checkoutService)
final checkoutServiceProvider =
    AutoDisposeProvider<FakeCheckoutService>.internal(
  checkoutService,
  name: r'checkoutServiceProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$checkoutServiceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef CheckoutServiceRef = AutoDisposeProviderRef<FakeCheckoutService>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
