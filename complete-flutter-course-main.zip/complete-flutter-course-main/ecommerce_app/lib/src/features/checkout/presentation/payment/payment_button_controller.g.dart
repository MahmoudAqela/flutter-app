// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'payment_button_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$paymentButtonControllerHash() =>
    r'9653769d4b0443de189066af1a62981bcf6ec9ae';

/// See also [PaymentButtonController].
@ProviderFor(PaymentButtonController)
final paymentButtonControllerProvider =
    AutoDisposeAsyncNotifierProvider<PaymentButtonController, void>.internal(
  PaymentButtonController.new,
  name: r'paymentButtonControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$paymentButtonControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PaymentButtonController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
