// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'remote_cart_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$remoteCartRepositoryHash() =>
    r'0499a0c2246763888ea62237d4e38733e6cde621';

/// See also [remoteCartRepository].
@ProviderFor(remoteCartRepository)
final remoteCartRepositoryProvider = Provider<RemoteCartRepository>.internal(
  remoteCartRepository,
  name: r'remoteCartRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$remoteCartRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef RemoteCartRepositoryRef = ProviderRef<RemoteCartRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
