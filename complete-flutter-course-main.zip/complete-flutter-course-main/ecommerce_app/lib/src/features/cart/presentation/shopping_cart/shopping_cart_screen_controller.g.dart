// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shopping_cart_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$shoppingCartScreenControllerHash() =>
    r'24035b115aa5ceac6df133b59a198ade490d9d37';

/// See also [ShoppingCartScreenController].
@ProviderFor(ShoppingCartScreenController)
final shoppingCartScreenControllerProvider = AutoDisposeAsyncNotifierProvider<
    ShoppingCartScreenController, void>.internal(
  ShoppingCartScreenController.new,
  name: r'shoppingCartScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$shoppingCartScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ShoppingCartScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
